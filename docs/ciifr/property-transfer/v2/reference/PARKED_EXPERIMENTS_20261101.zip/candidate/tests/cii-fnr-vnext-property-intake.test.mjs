import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {test} from 'node:test';
import {createTestDom} from './helpers/vnext-dom-env.mjs';
import {mountPropertyTransfer} from '../tabs/cii-workspace/cii-fnr-vnext/ui/property-transfer/panel.js';

const row=values=>values.map((v,i)=>String(v).padStart(i?13:15)).join('');
function valid() {
  return Buffer.from(['#$ VERSION',row([5,14,1252]),'#$ CONTROL',
    row([1,0,0,0,0,0]),row([0,0,0,0,0,0]),row([0,0,0,0,0,0]),row([0]),
    '#$ ELEMENTS',...Array.from({length:15},(_,i)=>row(i===0?[400,500,0,0,0,0]:[0,0,0,0,0,0])),
    '#$ MISCEL_1',row([1,0,0,0,0,0])].join('\r\n')+'\r\n');
}
const file=(bytes,name='TARGET.cii')=>({name,arrayBuffer:async()=>
  bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)});
const label=dom=>dom.root.querySelector('[data-pt-file-status="target"]').textContent;
function start() {const dom=createTestDom();return {dom,app:mountPropertyTransfer(dom.root)};}
async function load(dom,f) {
  dom.ptTargetFile.files=f?[f]:[];
  return dom.ptTargetFile.dispatchEvent({type:'change'});
}

test('generated V11 rejection reaches a terminal per-file status instead of Loading forever',async()=>{
  const bytes=await readFile(new URL('../converters/scripts/inputxml_profile_bm_cii_2019.cii',import.meta.url));
  const {dom,app}=start();
  await load(dom,file(bytes,'GENERATED_2019.cii'));
  assert.match(dom.ptStatus.textContent,/PROPERTY_V14_ONLY/);
  assert.doesNotMatch(label(dom),/Loading|Reading|Checking|fingerprint/);
  assert.match(label(dom),/Not loaded/);
  assert.match(label(dom),/V14/);
  assert.equal(app.getState().targetHash,undefined);
});
test('malformed CII and rejected file read both finish the owning file card',async()=>{
  for(const f of [file(Buffer.from('not a CII file')),
    {name:'READ_FAILED.cii',arrayBuffer:async()=>{throw new Error('disk unavailable');}}]) {
    const {dom,app}=start();await load(dom,f);
    assert.match(label(dom),/Not loaded/);assert.doesNotMatch(label(dom),/^Loading /);
    assert.match(dom.ptStatus.textContent,/Input rejected/);
    assert.equal(app.getState().targetHash,undefined);
  }
});
test('valid intake retains original bytes and produces ready state without an export',async()=>{
  const {dom,app}=start(),bytes=valid(),before=Buffer.from(bytes);
  await load(dom,file(bytes));
  assert.match(label(dom),/V14.*1 elements.*SHA-256/);
  assert.equal(app.getState().targetHash.length,64);
  assert.equal(app.getState().canWrite,false);assert.deepEqual(bytes,before);
});
test('a late rejected read cannot replace a newer successfully loaded file status',async()=>{
  const {dom,app}=start();let reject;
  const pending=load(dom,{name:'OLDER.cii',arrayBuffer:()=>new Promise((_,no)=>{reject=no;})});
  await Promise.resolve();await load(dom,file(valid(),'NEWER.cii'));
  const ready=label(dom),hash=app.getState().targetHash;
  reject(new Error('late failure'));await pending;
  assert.equal(label(dom),ready);assert.equal(app.getState().targetHash,hash);
});
test('clearing a pending read keeps the slot empty after the old read finishes',async()=>{
  const {dom,app}=start();let resolve;
  const pending=load(dom,{name:'OLDER.cii',arrayBuffer:()=>new Promise(yes=>{resolve=yes;})});
  await Promise.resolve();await load(dom,null);
  const bytes=valid();resolve(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
  await pending;assert.equal(label(dom),'No file loaded');
  assert.equal(app.getState().targetHash,undefined);
});
test('an actual stalled read is bounded and a later retry succeeds',async()=>{
  const {readPropertyFile}=await import('../tabs/cii-workspace/cii-fnr-vnext/ui/property-transfer/intake.js');
  await assert.rejects(readPropertyFile({arrayBuffer:()=>new Promise(()=>{})},{timeoutMs:10}),
    /PROPERTY_FILE_READ_TIMEOUT/);
  const bytes=valid(),loaded=await readPropertyFile(file(bytes));
  assert.equal(loaded.index.counts.NUMELT,1);assert.deepEqual(loaded.bytes,new Uint8Array(bytes));
});
test('repeated UNKNOWN records stay inspectable inside grouped closed details',async()=>{
  const lines=valid().toString('ascii').split('\r\n');
  lines[4]=row([1,0,0,1,0,0]);
  lines[lines.indexOf('#$ ELEMENTS')+13]=row([1,0,0,1,0,0]);
  lines.splice(lines.indexOf('#$ MISCEL_1'),0,'#$ RESTRANT',
    ...Array.from({length:24},(_,i)=>row(i===0?[400,1,0,0,0,0]:
      i===5||i===9?[1,0,0,0,0,0]:[0,0,0,0,0,0])));
  const {dom}=start();await load(dom,file(Buffer.from(lines.join('\r\n'))));
  const section=dom.ptResults.children[0];
  const groups=section.children.filter(e=>e.tagName==='DETAILS');
  assert.equal(groups.length,2);
  assert.ok(groups.every(e=>!e.open));
  const text=e=>[e.textContent,...e.children.map(text)].join(' ');
  const rendered=text(section);
  assert.match(rendered,/not a verdict that the CII is invalid/);
  assert.match(rendered,/BEND/);assert.match(rendered,/2 occurrence\(s\)/);
  assert.match(rendered,/Slot 2/);assert.match(rendered,/Slot 3/);
  assert.match(rendered,/UNKNOWN/);assert.match(rendered,/PROPERTY_RESTRAINT_DORMANT_RESIDUE/);
});
