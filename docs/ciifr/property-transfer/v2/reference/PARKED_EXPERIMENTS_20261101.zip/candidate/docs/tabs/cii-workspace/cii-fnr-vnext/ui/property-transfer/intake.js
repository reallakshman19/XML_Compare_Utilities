/* Property input custody only. Profile admission stays in the existing reader. */
import {indexCiiV14} from './cii-index.js';

async function within(promise,timeoutMs,code) {
  let timer;
  const expired=new Promise((_,reject)=>{
    timer=setTimeout(()=>reject(new Error(code)),timeoutMs);
  });
  try {return await Promise.race([promise,expired]);}
  finally {clearTimeout(timer);}
}

export function propertyLoadError(error) {
  const code=error?.message||String(error);
  if(code==='PROPERTY_V14_ONLY') return code+
    ' · This Property reader supports V14. Use the existing V11↔V14 converter '+
    'for an earlier profile; changing only a VERSION header is insufficient.';
  if(code==='PROPERTY_FILE_READ_TIMEOUT'||code==='PROPERTY_FILE_HASH_TIMEOUT')
    return code+' · The file operation timed out. Select the file again to retry.';
  return code;
}

export async function readPropertyFile(file,{timeoutMs=30000,onPhase=()=>{}}={}) {
  if(!file||typeof file.arrayBuffer!=='function') throw new Error('PROPERTY_FILE_REQUIRED');
  if(!Number.isFinite(timeoutMs)||timeoutMs<=0) throw new Error('PROPERTY_TIMEOUT_INVALID');
  onPhase('Reading file');
  const buffer=await within(Promise.resolve().then(()=>file.arrayBuffer()),
    timeoutMs,'PROPERTY_FILE_READ_TIMEOUT');
  const bytes=new Uint8Array(buffer);
  onPhase('Checking CII structure');
  const index=indexCiiV14(bytes);
  const subtle=globalThis.crypto?.subtle;
  if(!subtle) throw new Error('PROPERTY_HASH_UNAVAILABLE');
  onPhase('Computing file fingerprint');
  const digest=await within(subtle.digest('SHA-256',bytes),timeoutMs,'PROPERTY_FILE_HASH_TIMEOUT');
  const hash=[...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
  return {bytes,index,hash};
}
