/* Presentation of reader limits; does not change diagnostics or CII admission. */
function groups(diagnostics) {
  const result=new Map();
  for(const item of diagnostics) {
    const key=item.family+' · '+item.code;
    if(!result.has(key)) result.set(key,[]);
    result.get(key).push(item);
  }
  return result;
}

function detail(parent,item,cell) {
  if(item.ownerElement===undefined) return;
  const entry=document.createElement('details');
  entry.append(cell('Element '+item.ownerElement+' · Pointer '+item.pointer+
    ' · Slot '+item.slot+' · bytes '+item.byteStart+'–'+item.byteEnd,'summary'));
  if(item.rawCards) entry.append(cell(item.rawCards.join('\n'),'pre'));
  parent.append(entry);
}

export function showPropertyEvidence(docs,root,cell) {
  for(const [side,doc] of Object.entries(docs)) {
    const notes=doc?.index.diagnostics;
    if(!notes?.length) continue;
    const section=document.createElement('section');section.className='pt-result';
    section.append(cell(side.toUpperCase()+' · Reader coverage · '+notes.length+' note(s)','h3'));
    section.append(cell('UNKNOWN describes an inspection limit, not a verdict that the CII is invalid. '+
      'Inputs remain unchanged. Expand a group for the retained evidence.','p'));
    for(const [key,items] of groups(notes)) {
      const group=document.createElement('details'),first=items[0];
      const amount=first.count!==undefined?' · CONTROL count '+first.count:' · '+items.length+' occurrence(s)';
      group.append(cell('UNKNOWN · '+key+amount,'summary'));
      group.append(cell(first.detail,'p'));
      for(const item of items) detail(group,item,cell);
      section.append(group);
    }
    root.append(section);
  }
}
