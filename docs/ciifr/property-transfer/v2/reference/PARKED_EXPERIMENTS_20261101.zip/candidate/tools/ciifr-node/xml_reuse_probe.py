"""Read-only proof of the existing XML reconstruction path; never edits a model file."""
import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path


REFERENCE_HEAD = 'c2452deb96b402f0dda52f63748bc795049b46bc'
PINNED_FILES = {
    'prototypes/ciifr-xmlv3/xmlv3/__init__.py': 'cc48435cd7aa495dadec18c0fbd5de6ff1757f49',
    'prototypes/ciifr-xmlv3/xmlv3/baseline.py': '8370409c1192355dcebf1852f63beded6207db8b',
    'prototypes/ciifr-xmlv3/xmlv3/core.py': '176082ce9d11fc51ecc57434015896da9245ffd5',
    'prototypes/ciifr-xmlv3/xmlv3/guards.py': '9571fd7e572ede415e303b87d1651e6d05dd5d13',
    'prototypes/ciifr-xmlv3/xmlv3/views.py': '001a79987e46818b9a514ed981ecc406bf18032d',
    'prototypes/ciifr-xmlv2-r3/engine/engine.py': '5eaeb9c945032e4baa695feffcda60cb7bd1b570',
    'prototypes/ciifr-xmlv2-r3/engine/profile.py': '44e8c4be17c6ebb6e2034ca2c6c4e1679ebd1d89',
}


def require(condition, code):
    if not condition:
        raise ValueError(code)


def load_reference(root):
    for name, expected in PINNED_FILES.items():
        data = (root / name).read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        require(actual == expected, 'XML_REFERENCE_IDENTITY_MISMATCH:' + name)
    require(not any(n == 'xmlv3' or n.startswith('xmlv3.') for n in sys.modules),
            'XML_REFERENCE_NAMESPACE_ALREADY_LOADED')
    sys.path.insert(0, str(root / 'prototypes/ciifr-xmlv3'))
    from xmlv3 import core
    from xmlv3 import views
    return core, views


def node_fields(root, index):
    nodes = root.findall('./EngineeringViews/Nodes/Node')
    owners = {}
    for node in nodes:
        for item in node.findall('./Data/NameOccurrence'):
            owners.setdefault(item.get('field'), set()).add(node.get('id'))
    for node in nodes:
        refs = {e.get('field') for e in node.findall('./Data/NameOccurrence')}
        if (refs and all(len(owners[key]) == 1 for key in refs)
                and any(index[key].get('value', '').strip() for key in refs)):
            return refs
    raise ValueError('NO_EXCLUSIVELY_OWNED_NAMED_NODE_FOR_PROBE')


def physical_name_rows(data):
    rows, inside, offset = [], False, 0
    for line in data.splitlines(keepends=True):
        if line.rstrip(b'\r\n') == b'#$ NODENAME':
            inside = True
        elif line.lstrip().startswith(b'#$') and inside:
            break
        elif inside and line.strip():
            rows.append((offset, line))
        offset += len(line)
    return rows


def expected_edit(data, refs, index, replacement):
    # Independent physical oracle: (2X,A25,1X,A25), not serializer output.
    rows, expected = physical_name_rows(data), bytearray(data)
    for key in refs:
        record, name = key.split('/')
        ordinal = int(record.rsplit('-', 1)[1])
        require(name in ('from_node_name', 'to_node_name'), 'NOT_A_NODE_NAME_FIELD')
        start, end = (2, 27) if name == 'from_node_name' else (28, 53)
        offset, line = rows[ordinal - 1]
        require(line[start:end].decode('ascii') == index[key].get('value'),
                'XML_FIELD_AND_PHYSICAL_ORACLE_DISAGREE')
        expected[offset + start:offset + end] = replacement.encode('ascii')
    return bytes(expected)


def probe(reference_root, model):
    core, views = load_reference(reference_root)
    data = model.read_bytes()
    before = hashlib.sha256(data).digest()
    root = core.from_cii(data)
    require(core.to_cii(core.load_xml(core.xml_bytes(root))) == data, 'NOOP_ROUNDTRIP_DIFFERENT')
    index = views.field_index(core.storage_of(root))
    refs = node_fields(root, index)
    replacement = 'XML-EDIT-PROBE'.ljust(25)
    expected = expected_edit(data, refs, index, replacement)
    changed = copy.deepcopy(root)
    fields = views.field_index(core.storage_of(changed))
    for key in refs:
        fields[key].set('value', replacement)
        fields[key].set('edited', 'true')
    changed.remove(changed.find('EngineeringViews'))
    changed.append(views.build_views(core.storage_of(changed)))
    # Existing writer receives XML only. No original-CII argument or replay.
    actual = core.to_cii(core.load_xml(core.xml_bytes(changed)))
    require(actual == expected, 'NODE_EDIT_DIFFERS_FROM_INDEPENDENT_EXPECTATION')
    require(hashlib.sha256(model.read_bytes()).digest() == before, 'ORIGINAL_CHANGED')
    return {
        'referenceHead': REFERENCE_HEAD, 'referenceFilesVerified': len(PINNED_FILES),
        'check': 'EXISTING_XMLV3_NODE_WISE_NAME_EDIT_REUSE',
        'oracle': 'INDEPENDENT_LITERAL_NODENAME_A25_CARD_SLICES',
        'noopRoundtrip': 'BYTE_EXACT_PASS', 'xmlOnlyNodeWiseNameEdit': 'PASS',
        'logicalNodeAliasFieldsUpdated': len(refs), 'approvedSpansOnly': 'PASS',
        'originalUnchanged': 'PASS', 'privateEvidence': 'NOT_PUBLISHED',
        'nativeCAESARImport': 'NOT_RUN', 'browserIntegration': 'NOT_RUN',
        'restraintPropertySemantics': 'NOT_QUALIFIED_BY_NAME_EDIT',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-root', required=True, type=Path,
                        help='Read-only PR206 repository/subset containing the seven exact pinned files')
    parser.add_argument('--model', required=True, type=Path, help='Owner-authorized CII; never modified')
    args = parser.parse_args()
    try:
        result = probe(args.reference_root.resolve(), args.model.resolve())
    except (OSError, ValueError, ImportError) as error:
        print('XML_REUSE_PROBE_FAILED: ' + str(error), file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
