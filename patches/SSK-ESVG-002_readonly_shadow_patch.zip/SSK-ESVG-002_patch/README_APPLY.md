# SSK-ESVG-002 patch bundle

Target repository:

```text
reallaksh19/XML_Compare_Utilities
```

Authoritative Work Pack:

```text
Issue #462 — SSK-ESVG-002: Read-only Sequential shared-workspace shadow mount
```

Grounding baseline used to prepare this patch:

```text
main = b0327a5c6fcc3c6acad726b5199030b10179138e
```

## Included repository files

```text
tabs/sequential-sketcher/sequential-engineering-svg-shadow-workspace.js
tests/sequential-engineering-svg-shadow-ownership.test.js
tests/sequential-engineering-svg-shadow-dependency-guard.test.js
tests/sequential-engineering-svg-shadow-parity.test.js
tests/browser/sequential-engineering-svg-shadow-fixture.html
tests/browser/sequential-engineering-svg-shadow.spec.mjs
playwright.sequential-engineering-svg-shadow.config.mjs
.github/workflows/sequential-engineering-svg-shadow.yml
```

No existing repository file is replaced by this bundle.

## Apply

From a clean, current checkout:

```bash
git fetch origin
git switch main
git pull --ff-only
git switch -c agent/ssk-esvg-002-shadow-workspace
```

Create the repository-required local `.agent-worklogs` manifest before copying product files. Because all patch files are new, record `no pre-image` and deletion-by-checksum as the undo rule. Do not commit `.agent-worklogs/**` or `.backups/**`.

Copy the files:

```bash
rsync -av SSK-ESVG-002_patch/repo/ ./
```

Alternatively:

```bash
git apply SSK-ESVG-002_patch/ssk-esvg-002.patch
```

Verify the bundle before applying:

```bash
cd SSK-ESVG-002_patch
sha256sum -c SHA256SUMS.txt
```

## Focused validation

```bash
node --check tabs/sequential-sketcher/sequential-engineering-svg-shadow-workspace.js
node --check tests/sequential-engineering-svg-shadow-ownership.test.js
node --check tests/sequential-engineering-svg-shadow-dependency-guard.test.js
node --check tests/sequential-engineering-svg-shadow-parity.test.js
node --check tests/browser/sequential-engineering-svg-shadow.spec.mjs
node --check playwright.sequential-engineering-svg-shadow.config.mjs

node tests/sequential-engineering-svg-shadow-ownership.test.js
node tests/sequential-engineering-svg-shadow-parity.test.js
node tests/sequential-engineering-svg-shadow-dependency-guard.test.js

npm ci
npx playwright install --with-deps chromium
npx playwright test --config=playwright.sequential-engineering-svg-shadow.config.mjs
npm test
```

The dedicated workflow runs B01–B05 as individually blocking Chromium cases, the shared Engineering Scene/SVG contracts, merged Sequential adapter gates, construction/continuity/support regressions, syntax, startup smoke, and the full repository test suite.

## Design notes

The production wrapper imports only:

```text
SequentialEngineeringSvgAdapter.v1
EngineeringSvgAdapterBridge.v1
EngineeringSvgWorkspaceShell.v1 shell runtime
```

It validates owner events before they reach the bridge, preserves the three approved architectural omissions, rejects stale support evidence and mapped-category inconsistencies, reconciles selection by stable entity identity, removes partial shell roots after mount failure, and destroys its scene subscription, shell, and bridge idempotently.

It does not import construction advancement, decision execution, repair execution, the existing Sequential renderer/projection, application navigation, Three.js, React, WebGL, storage, snap, edit, command, or draft runtimes.

## Inherited source limitation

The protected merged property provider does not currently expose these two values as inspector fields:

- rejected decision `resolution.action`;
- support construction fingerprint.

The merged adapter does preserve them respectively in entity decision metadata and the parity revision-consistency evidence. The browser proof checks those authoritative locations and keeps the inspector read-only. Adding literal inspector fields would require modifying the protected `sequential-engineering-svg-properties.js`, which Issue #462 forbids.

## Validation status of this bundle

The new JavaScript and MJS files passed `node --check`. Full repository tests and Chromium were not run while preparing the ZIP because the available environment did not contain a writable repository checkout or installed repository dependencies. Run the commands above after applying.
