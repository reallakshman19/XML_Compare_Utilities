# RC-SVG-001A patch bundle

Base repository: `reallaksh19/XML_Compare_Utilities`  
Base `main` SHA: `b0327a5c6fcc3c6acad726b5199030b10179138e`  
Target branch: `rc-svg-001a-overlay-preview`  
Required draft PR title: `feat: add revision SVG overlay preview`

## Included

- `RC-SVG-001A.patch` — git-apply patch for production integration and focused Node tests.
- `repo-overlay/` — complete copies of every newly added file for inspection/manual recovery.
- `apply_rc_svg_001a.sh` — creates the required local worklog, runs repository backups for existing files, checks and applies the patch.
- `validate_rc_svg_001a.sh` — required local validation command sequence.

## Production behavior in this bundle

- WebGL remains the default.
- Adds `3D (WebGL) | SVG preview` presentation selector.
- Adds a common viewer contract and backend-aware adapter.
- Projects immutable `VisualGeometryModel.v2` evidence into `EngineeringScene.v1` without coordinate invention or transformation.
- Uses the shared read-only Engineering SVG workspace directly; no SVG property inspector or edit runtime is mounted.
- Adds Revision Compare-owned status classes/data attributes and accessible status labels.
- Preserves queue selection and persisted candidate-preview IDs.
- Forces SVG overlay mode; linked SVG side-by-side remains disabled with the RC-SVG-001B explanation.
- Captures JSON-safe backend snapshots, disposes before switching, and permits WebGL recovery after SVG failure.
- Includes deterministic, immutable, JSON-safe, missing-geometry, status-table, lifecycle, contract, and 5,000-entity tests.

## Important limitations

This bundle was generated without a writable repository checkout. It has been syntax-checked as standalone JavaScript, but it has **not** been certified by the repository's full tests, real Chromium journey, GitHub workflows, or Pages deployment. The Work Pack remains incomplete until those validations pass on the exact committed head.

The bundle does not add a new Playwright journey or modify `.github/workflows/revision-compare.yml`; those must be completed if the current repository does not already provide sufficient RC-SVG-001A exact-head/browser coverage.

## Apply

```bash
unzip RC-SVG-001A_patch_bundle.zip
cd /path/to/XML_Compare_Utilities
/path/to/RC-SVG-001A_patch_bundle/apply_rc_svg_001a.sh
/path/to/RC-SVG-001A_patch_bundle/validate_rc_svg_001a.sh
```

Then inspect `git diff`, commit, push, and open a **draft** PR whose body begins:

```text
Closes #454

Mission RC-SVG-001A
```
