#!/usr/bin/env bash
set -euo pipefail
node --check tabs/revision-compare/*.js
npm run test:revision-compare
npm run test:workbench3d
npm test
npx playwright test --config=playwright.revision-compare.config.mjs
