#!/usr/bin/env bash
set -euo pipefail

BASE_SHA="b0327a5c6fcc3c6acad726b5199030b10179138e"
BRANCH="rc-svg-001a-overlay-preview"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_FILE="$BUNDLE_DIR/RC-SVG-001A.patch"

[[ -d .git ]] || { echo "Run this from the XML_Compare_Utilities repository root." >&2; exit 1; }
[[ -f AGENTS.md && -f utils/backup.cjs ]] || { echo "Repository governance/backup tooling not found." >&2; exit 1; }
CURRENT="$(git rev-parse HEAD)"
if [[ "$CURRENT" != "$BASE_SHA" ]]; then
  echo "Patch was authored against $BASE_SHA; current HEAD is $CURRENT." >&2
  echo "Review drift, then run: git apply --check '$PATCH_FILE'" >&2
fi

git diff --quiet && git diff --cached --quiet || { echo "Working tree must be clean before applying this bundle." >&2; exit 1; }
if [[ "$(git branch --show-current)" != "$BRANCH" ]]; then
  if git show-ref --verify --quiet "refs/heads/$BRANCH"; then git switch "$BRANCH"; else git switch -c "$BRANCH"; fi
fi

STAMP="$(date +%Y%m%d_%H%M)"
WORKLOG=".agent-worklogs/${STAMP}_rc-svg-001a-overlay-preview"
mkdir -p "$WORKLOG/modules"
cat > "$WORKLOG/manifest.md" <<EOF
# RC-SVG-001A local patch application

- Base expected: $BASE_SHA
- Actual pre-apply HEAD: $CURRENT
- Branch: $BRANCH
- Bundle: $PATCH_FILE

| Module | Status | Planned | Did | Validation | Patch | Backups | Undo |
|---|---|---|---|---|---|---|---|
| Revision Compare SVG overlay | in_progress | Apply bundled overlay implementation | Pending | Pending | modules/revision-compare-svg.patch | See module log | Restore recorded backups / delete checksum-matched new files |
EOF
cp "$PATCH_FILE" "$WORKLOG/modules/revision-compare-svg.patch"
cat > "$WORKLOG/modules/revision-compare-svg.md" <<'EOF'
# Module: Revision Compare SVG overlay
## Planned
Apply RC-SVG-001A read-only overlay backend without changing comparison, review, or decision evidence.
## Did
Pending application.
## Technical details
Patch authored against the base recorded in manifest.md.
## Files and symbols
See bundled MANIFEST.md.
## Upstream/downstream impact
Revision Compare presentation path only; shared core and Workbench remain read-only dependencies.
## Validation
Pending local commands.
## Patch and backups
Backup receipts follow below.
## Undo
Verify current checksums first. Restore existing-file backups or remove only new files whose checksum still matches the manifest.
## Remaining risks or follow-ups
Real Chromium journey and exact-head workflows remain mandatory.
EOF

EXISTING=(
  tabs/revision-compare/revision-compare-viewer-adapter.js
  tabs/revision-compare/revision-compare-lifecycle.js
  tabs/revision-compare/revision-workspace-state.js
  tabs/revision-compare/revision-compare-actions.js
  tabs/revision-compare/revision-compare-workspace.js
  tabs/revision-compare/revision-compare-review-view.js
  tabs/revision-compare/revision-compare-view.js
  tests/revision-compare-foundation.test.mjs
)
for file in "${EXISTING[@]}"; do
  before="$(sha256sum "$file" | awk '{print $1}')"
  receipt="$(node utils/backup.cjs save "$file" "RC-SVG-001A: apply read-only SVG overlay preview")"
  printf '\n### %s\n- Original SHA-256: `%s`\n- Backup receipt:\n```text\n%s\n```\n' "$file" "$before" "$receipt" >> "$WORKLOG/modules/revision-compare-svg.md"
done

git apply --check "$PATCH_FILE"
git apply "$PATCH_FILE"

printf '\n## Post-apply SHA-256\n' >> "$WORKLOG/modules/revision-compare-svg.md"
while IFS= read -r file; do
  [[ -f "$file" ]] || continue
  printf -- '- `%s`: `%s`\n' "$file" "$(sha256sum "$file" | awk '{print $1}')" >> "$WORKLOG/modules/revision-compare-svg.md"
done < <(sed -n 's#^+++ b/##p' "$PATCH_FILE" | sort -u)

cat >> "$WORKLOG/modules/revision-compare-svg.md" <<EOF

## Validation commands to run
\`node --check tabs/revision-compare/*.js\`
\`npm run test:revision-compare\`
\`npm run test:workbench3d\`
\`npm test\`
\`npx playwright test --config=playwright.revision-compare.config.mjs\`
EOF

echo "Patch applied. Worklog: $WORKLOG"
echo "Run ./validate_rc_svg_001a.sh, inspect the diff, commit, push, and open the required draft PR."
